# Cutoff Compass — Backend

Flask backend for the TNEA College Predictor frontend ("Cutoff Compass").

## What it does
- Serves the same college cutoff dataset used by the frontend (`data.json`)
- Recreates the exact prediction logic from the frontend JS (`calcProbability`, `getTier`, `getTierLabel`)
- Exposes a small REST API so the frontend can fetch data instead of using a hardcoded JS array

## Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/health` | Health check, returns record count |
| GET | `/api/meta` | Returns colleges, branches, communities for dropdowns |
| POST | `/api/predict` | Main prediction endpoint |
| GET | `/api/table` | Filterable raw data table (Data Explorer section) |

### `POST /api/predict`
Request body:
```json
{
  "score": 195.5,
  "community": "OC",
  "branch": "",
  "year": "2025"
}
```
Response:
```json
{
  "score": 195.5,
  "community": "OC",
  "total_matches": 9,
  "high_count": 3,
  "medium_count": 6,
  "results": [ { "college": "...", "branch": "...", "probability": 95, "tier": "high", "...": "..." } ]
}
```

### `GET /api/table?college=&branch=&community=`
Returns raw cutoff rows, filterable via query params (all optional).

## Setup

```bash
cd backend
pip install -r requirements.txt
python app.py
```

Server runs at `http://localhost:5000`.

## Connecting to the frontend
In `index.html`, replace the hardcoded `DATA` array logic with `fetch()` calls to these endpoints, e.g.:

```js
const res = await fetch('http://localhost:5000/api/predict', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ score, community, branch, year })
});
const data = await res.json();
```

## Tech stack
- Python 3 / Flask
- Flask-CORS (so the frontend can call the API from a different port/origin)
