# 🧭 Cutoff Compass — TNEA College Cutoff Predictor

A web app that helps Tamil Nadu engineering aspirants predict their admission chances at various colleges based on their TNEA cutoff score, community category, and branch preference — using historical cutoff data (2023–2025) across 115 college/branch/community records.

## Features
- Predicts admission probability (Likely / Moderate / Unlikely) for each college & branch
- Filters by community category, branch, and cutoff year
- Data Explorer table to browse raw cutoff data
- Visual cutoff trend bars across 2023, 2024, 2025

## Project structure
```
.
├── index.html          # Frontend (can run standalone, or connect to the backend API)
└── backend/
    ├── app.py           # Flask API
    ├── data.json        # Cutoff dataset (115 records)
    ├── requirements.txt
    └── README.md
```

## Running it

### Frontend only (quickest way to try it)
Just open `index.html` in a browser — it works standalone with a built-in dataset, no backend required.

### With the backend API
```bash
cd backend
pip install -r requirements.txt
python app.py
```
The API runs at `http://localhost:5000`. See [`backend/README.md`](backend/README.md) for endpoint details.

## Tech stack
- HTML / CSS / vanilla JS (frontend)
- Python, Flask, Flask-CORS (backend API)

## Author
Built by Nobita — AI & Data Science student, V.S.B. Engineering College.

## License
MIT — feel free to use, fork, and adapt.
